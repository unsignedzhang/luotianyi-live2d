﻿=== PoiLive2D ===
Contributors: 戴兜 & unsignedzhang
Tags: html5, live2d, 人偶, 看板娘
Requires at least: 3.5
Tested up to: 4.9.7
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

添加一个Live2D人物在你的博客里

== Description ==

添加一个洛天依Live2D人物在你的博客里
原模型来自手游 药水制作师
贴图修改：unsignedzhang
详细介绍： http://unsignedzhang.cn/2019/04/19/tianyi-live2d


== Installation ==

1. 上传 插件 到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件

== Changelog ==
= 1.1.0 =
* 通过贴图修改制作的洛天依模型
* 增加音乐播放功能

= 1.0.5E =
* 假装修复了白猫主题没法初始化模型的问题

= 1.0.5 =
* 修复后台异常输出
* 优化代码结构
* 增加换装功能

= 1.0.4 =
* 修复设置页面json保存后出现反斜杠的问题

= 1.0.2 =
* 修复header错误输出的问题

= 1.0.1 =
* 新增插件设置页面

= 1.0.0 =
* 初始版本发布